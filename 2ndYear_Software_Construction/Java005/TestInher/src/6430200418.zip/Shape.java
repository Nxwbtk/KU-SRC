/*
 * Name     : Bunthakan Sirikamonthip
 * ID       : 6430200418
 * Section  : 831
 */
public class Shape {
    public double getArea() {
        return 0;
    }
}
